public class PictureJavaProgram
{
	public static void main ( String [] args )
	{
		char firstlevel = '*';
		String secondlevel = "* *";
		String thirdlevel = "*   *";
		String fourthlevel = "*     *";
		String fifthlevel = "**** ****";

		System.out.println( "      " + firstlevel);
		System.out.println( "     " + secondlevel);
		System.out.println( "    " + thirdlevel);
		System.out.println( "   " + fourthlevel);
		System.out.println( "  " + fifthlevel );
		System.out.println("     " + secondlevel);
		System.out.println("     " + secondlevel);
		System.out.println("     " + secondlevel);
		System.out.println( "  " + fifthlevel );
		System.out.println( "   " + fourthlevel);
		System.out.println( "    " + thirdlevel);
		System.out.println( "     " + secondlevel);
		System.out.println( "      " + firstlevel);
	}
}